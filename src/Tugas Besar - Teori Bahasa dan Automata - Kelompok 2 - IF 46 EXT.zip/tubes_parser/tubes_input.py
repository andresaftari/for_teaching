# /*
# Kelompok 2:
# 1. Basari Resha (1301228443)
# 2. Prasidya Pramadresana Saftari (1301228479)
# 3. Naufal Sayyid (1301228484)
#  */

# /*
# File ini digunakan untuk memberikan input yang akan diuji, ketik satu atau lebih baris kode
# sepertic contoh di bawah komentar ini
# */

a = 1

if a == 1:
    print('One')
else:
    print('Not One or Two')
