package Semester3.Topik5.Lingkaran;

public class Main {
    static Lingkaran lingkaran1 = new Lingkaran(7f);
    static Lingkaran lingkaran2 = new Lingkaran(5.5f);
    static Lingkaran lingkaran3 = new Lingkaran(20.4);
    static double luas, keliling;
    private static final double pi = 3.14;

    public static void main(String[] args) {
        luas = pi * (lingkaran1.getJejari() * lingkaran1.getJejari());
        System.out.println("Luas lingkaran 1: " + luas);

        luas = pi * (lingkaran2.getJejari() * lingkaran2.getJejari());
        System.out.println("Luas lingkaran 2: " + luas);

        luas = (pi * (lingkaran3.getDiameter() * lingkaran3.getDiameter())) / 4;
        System.out.println("Luas lingkaran 3: " + luas);

        keliling = 2 * pi * lingkaran1.getJejari();
        System.out.println("\nKeliling lingkaran 1: " + keliling);

        keliling = 2 * pi * lingkaran2.getJejari();
        System.out.println("Keliling lingkaran 2: " + keliling);

        keliling = pi * lingkaran3.getDiameter();
        System.out.println("Keliling lingkaran 3: " + keliling);
    }
}