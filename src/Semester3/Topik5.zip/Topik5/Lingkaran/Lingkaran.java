package Semester3.Topik5.Lingkaran;

public class Lingkaran {
    float jejari;
    double diameter;

    public Lingkaran(float jejari) {
        this.jejari = jejari;
    }

    public Lingkaran(double diameter) {
        this.diameter = diameter;
    }

    public float getJejari() {
        return jejari;
    }

    public double getDiameter() {
        return diameter;
    }
}