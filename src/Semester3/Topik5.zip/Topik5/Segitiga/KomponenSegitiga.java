package Semester3.Topik5.Segitiga;

// Class ini adalah induk class (SuperClass)
public class KomponenSegitiga {
    int komponen1, komponen2;

    public KomponenSegitiga(int komponen1, int komponen2) {
        this.komponen1 = komponen1;
        this.komponen2 = komponen2;
    }
}