package com.tabungan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Main {
    static Orang nasabah;
    static Tabungan tabungan;
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {
        int input;

        do {
            System.out.print("\nSelamat datang di ATM aneh, silakan pilih input :\n" +
                    "1. Buat akun\n" +
                    "2. Deposit saldo\n" +
                    "3. Withdraw saldo\n" +
                    "4. Statistik keuangan\n" +
                    "5. Batalkan transaksi\n\n" +
                    "Pilihan Anda : ");

            input = Integer.parseInt(br.readLine());

            switch (input) {
                case 1:
                    addNewAccount();
                    break;

                case 2:
                    depositMoney();
                    break;

                case 3:
                    withdrawMoney();
                    break;

                case 4:
                    getStatistic();
                    break;

                case 5:
                    System.exit(0);

                default:
                    System.out.println("Silakan input opsi yang benar!");

            }
        } while (true);
    }

    static void addNewAccount() throws IOException {
        System.out.print("Mau buat berapa tabungan? ");
        int accountQty = Integer.parseInt(br.readLine());
        int[] arrayOfAccount = new int[accountQty];

        for (int i = 0; i < arrayOfAccount.length; i++) {
            System.out.print("Input NIK : ");
            long nik = Long.parseLong(br.readLine());
            System.out.print("Input nama : ");
            String nama = br.readLine();

            nasabah = new Orang(nama, nik);
            tabungan = new Tabungan(nama, Math.abs(new Random().nextLong()));
            nasabah.addRekening(tabungan);

            System.out.println(nasabah.toString());
        }
    }

    static void depositMoney() throws IOException {
        System.out.print("Input nama Anda : ");
        String nama = br.readLine();
        System.out.print("Input nomor rekening Anda : ");
        long nomorRek = Long.parseLong(br.readLine());

        nasabah = new Orang(nama);
        for (Tabungan rekening : nasabah.getRekening()) {
            if (nomorRek == rekening.getNomorRek()) {
                System.out.print("Input jumlah uang yang akan di-deposit : ");
                double jumlahUang = Double.parseDouble(br.readLine());
                rekening.depositSaldo(jumlahUang);
            }
        }
    }

    static void withdrawMoney() throws IOException {
        System.out.print("Input nama Anda : ");
        String nama = br.readLine();
        System.out.print("Input nomor rekening Anda : ");
        long nomorRek = Long.parseLong(br.readLine());

        nasabah = new Orang(nama);
        for (Tabungan rekening : nasabah.getRekening()) {
            if (nomorRek == rekening.getNomorRek()) {
                System.out.println("Input jumlah uang yang akan di-withdraw : ");
                double jumlahUang = Double.parseDouble(br.readLine());
                rekening.withdrawSaldo(jumlahUang);
            }
        }
    }

    static void getStatistic() throws IOException {
        System.out.print("Input nama Anda : ");
        String nama = br.readLine();

        nasabah = new Orang(nama);
        for (Tabungan tabungan : nasabah.getRekening())
            if (nasabah.getNama().equalsIgnoreCase(tabungan.getNasabah())) tabungan.getStatistic();
    }
}