package com.tabungan;

public class Saldo {
    private final double jumlahUang;

    public Saldo(double jumlahUang) {
        this.jumlahUang = jumlahUang;
    }

    public double getJumlahUang() {
        return jumlahUang;
    }

    @Override
    public String toString() {
        return "\nJumlah saldo : " + getJumlahUang();
    }
}