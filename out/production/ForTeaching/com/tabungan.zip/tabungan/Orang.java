package com.tabungan;

import java.util.ArrayList;

public class Orang {
    String nama;
    long nik;
    ArrayList<Tabungan> rekening = new ArrayList<>();

    public Orang(String nama, long nik) {
        this.nama = nama;
        this.nik = nik;
    }

    public Orang(String nama) {
        this.nama = nama;
    }

    public void addRekening(Tabungan tabungan) {
        getRekening().add(tabungan);
    }

    public String getNama() {
        return nama;
    }

    public long getNik() {
        return nik;
    }

    public ArrayList<Tabungan> getRekening() {
        return rekening;
    }

    @Override
    public String toString() {
        return "Data rekening nasabah :" +
                "\nNik : " + getNik() +
                "\nNama : " + getNama() +
                "\nRekening yang dimiliki : " + getRekening().toString();
    }
}
