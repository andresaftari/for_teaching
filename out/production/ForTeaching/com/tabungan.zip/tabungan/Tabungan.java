package com.tabungan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Tabungan implements Comparator<Saldo> {
    private final String nasabah;
    private final long nomorRek;
    private final ArrayList<Saldo> listSaldo = new ArrayList<>();

    public Tabungan(String nasabah, long nomorRek) {
        this.nasabah = nasabah;
        this.nomorRek = nomorRek;
    }

    public String getNasabah() {
        return nasabah;
    }

    public long getNomorRek() {
        return nomorRek;
    }

    public void depositSaldo(double saldo) {
        listSaldo.add(new Saldo(saldo));
    }

    public void withdrawSaldo(double saldo) {
        listSaldo.remove(new Saldo(saldo));
    }

    public void getStatistic() {
        for (Saldo saldo : listSaldo) {
            System.out.println("Total : " + saldo.toString());
            System.out.println("Saldo tertinggi : " + Collections.max(listSaldo, this));
            System.out.println("Saldo terendah : " + Collections.min(listSaldo, this));
        }
    }

    @Override
    public String toString() {
        return "Rekening " + getNomorRek() + " a/n " + getNasabah();
    }

    @Override
    public int compare(Saldo o1, Saldo o2) {
        return Double.compare(o2.getJumlahUang(), o1.getJumlahUang());
    }
}