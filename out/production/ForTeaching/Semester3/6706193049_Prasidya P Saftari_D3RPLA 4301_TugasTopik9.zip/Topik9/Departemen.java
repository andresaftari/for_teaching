package Semester3.Topik9;

import java.util.Arrays;

public class Departemen {
    private final String nama;
    private final Karyawan[] kar = new Karyawan[2];

    public Departemen(String nama) {
        this.nama = nama;
    }

    public void addKaryawan(Karyawan karyawan) {
        for (int i = 0; i < kar.length; i++) {
            if (kar[i] != null && i < kar.length - 1) {
                kar[i + 1] = karyawan;
            } else {
                kar[i] = karyawan;
            }
        }
    }

    public void displayAll() {
        System.out.println("\n===========Seluruh Karyawan di Departemen " + getNama() + "===========\n");
        for (Karyawan karyawan : kar) karyawan.display();
    }

    public void displayKontrak() {
        System.out.println("\n===========Karyawan Kontrak===========\n");
        Arrays.stream(kar).filter(it -> it.status == 0).forEach(Karyawan::display);
    }

    public void displayTetap() {
        System.out.println("\n===========Karyawan Tetap===========\n");
        Arrays.stream(kar).filter(it -> it.status == 1).forEach(Karyawan::display);
    }

    public String getNama() {
        return nama;
    }
}